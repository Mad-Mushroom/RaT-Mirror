This program will automatically download and install ReRaT.

For more information, read the README.txt of ReRaT (%AppData%/ReRaT/README.txt);